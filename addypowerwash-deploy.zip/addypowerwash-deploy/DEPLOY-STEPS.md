# Put addypowerwash.com back online — exact steps (~10 minutes)

Your domain already points at GitHub — the only missing piece is the site
files and the Pages setting. No repo currently hosts the site, so use a
fresh repo (do NOT reuse the old `addypowerwash2/addypowerwash2` template repo).

## 1. Unzip the bundle
Unzip `addypowerwash-deploy.zip` on your computer. You should see:
`index.html`, `CNAME`, `icon.jpg`, and an `assets` folder.

## 2. Create a new repo
- Go to github.com (log in) → click **+** (top right) → **New repository**
- Repository name: `addy-website`
- Set it **Public** → **Create repository**
- On the new repo page, click the **"uploading an existing file"** link

## 3. Upload the files
- Drag in `index.html`, `CNAME`, `icon.jpg`, and the whole `assets` folder
  (your browser can drop the folder in one go — keep the structure as-is)
- Click **Commit changes**

## 4. Turn on Pages
- In the repo, click **Settings** → **Pages** (left sidebar)
- Under "Build and deployment", Source: **Deploy from a branch**
- Branch: **main**, folder: **/(root)** → **Save**

## 5. Add your domain
- In that same Pages section, find **Custom domain**
- Type `addypowerwash.com` → **Save**
- (The CNAME file you uploaded does the same job — this just confirms it.)

## 6. Wait, then verify
- Give it 5–10 minutes. Open **https://addypowerwash.com** on your phone.
- You should see your business site. The www version redirects automatically.
- If the browser still shows a warning after 15 minutes, go back to
  Settings → Pages and check **Enforce HTTPS** (it appears once GitHub
  issues the certificate).

That's it — your Google and Yelp listings will land on a working site again.
